<?php
session_start();
require_once __DIR__ . '/../../private/config.php';

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $user = trim($_POST['user'] ?? '');
  $pass = trim($_POST['pass'] ?? '');

  if ($user === $ADMIN_USER && hash('sha256', $pass) === $ADMIN_PASS_HASH) {
    $_SESSION['admin_logged_in'] = true;
    header("Location: quotes.php");
    exit;
  } else {
    $error = "Invalid credentials.";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Login | <?=$SITE_NAME?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
<main class="container" style="max-width:500px;">
  <h1>Admin Login</h1>
  <?php if ($error): ?><div class="alert error"><?=htmlspecialchars($error)?></div><?php endif; ?>
  <form method="post" class="form-card">
    <label>Username
      <input type="text" name="user" required>
    </label>
    <label>Password
      <input type="password" name="pass" required>
    </label>
    <button type="submit" class="cta-btn">Login</button>
  </form>
</main>
</body>
</html>