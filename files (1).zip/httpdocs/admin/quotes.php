<?php
session_start();
require_once __DIR__ . '/../../private/config.php';
if (!isset($_SESSION['admin_logged_in'])) {
  header("Location: login.php");
  exit;
}

$mysqli = new mysqli($db_host, $db_user, $db_password, $db_name);
if ($mysqli->connect_errno) {
  die("Database connection failed.");
}

$status_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_quote'])) {
  $id = intval($_POST['id']);
  $quoted_price = trim($_POST['quoted_price'] ?? '');
  $payment_link = trim($_POST['payment_link'] ?? '');
  $quote_details = trim($_POST['quote_details'] ?? '');

  $stmt = $mysqli->prepare("SELECT email, first_name, last_name, metal_thickness FROM quote_requests WHERE id=?");
  $stmt->bind_param("i", $id);
  $stmt->execute();
  $stmt->bind_result($email, $first_name, $last_name, $metal_thickness);
  if ($stmt->fetch()) {
    $stmt->close();
    $subject = "Your Quote and Payment Link from $SITE_NAME";
    $message = "Dear $first_name $last_name,

Thank you for your quote request. Here are your quote details:

$quote_details

Quoted Price: $quoted_price

Payment Link:
$payment_link

Once payment is received, we will begin manufacture.

Best regards,
$SITE_NAME Team
";
    $headers  = "From: $SITE_NAME <".$SITE_EMAIL_FROM.">\r\n";
    $headers .= "Reply-To: ".$SITE_EMAIL_FROM."\r\n";
    $headers .= "Content-Type: text/plain; charset=utf-8\r\n";
    if (@mail($email, $subject, $message, $headers)) {
      $update = $mysqli->prepare("UPDATE quote_requests SET status='Quote Sent', quoted_price=?, payment_link=? WHERE id=?");
      $update->bind_param("ssi", $quoted_price, $payment_link, $id);
      $update->execute();
      $update->close();
      $status_msg = "Quote email sent to $first_name $last_name.";
    } else {
      $status_msg = "Failed to send email.";
    }
  } else {
    $status_msg = "Record not found.";
    $stmt->close();
  }
}

$result = $mysqli->query("SELECT id, first_name, last_name, email, phone, address, metal_thickness, comments, filename, status, created_at FROM quote_requests ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Quotes | <?=$SITE_NAME?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="../css/styles.css">
  <style>
    .admin-table { width:100%; border-collapse: collapse; background:#fff; margin-top:1em;}
    .admin-table th, .admin-table td { border:1px solid #ddd; padding:8px; vertical-align:top;}
    .admin-table th { background:#f0f4f5;}
    .quote-action-form { background:#f7ffff; border:1px solid #b5e1db; padding:10px; margin-top:8px;}
    .small { font-size:0.85em; color:#555; }
  </style>
</head>
<body>
<nav class="navbar">
  <a href="../index.php">Home</a>
  <a href="quotes.php" class="active">Quotes</a>
  <a href="logout.php" style="margin-left:auto;">Logout</a>
</nav>
<main class="container">
  <h1>Quote Requests</h1>
  <?php if ($status_msg): ?>
    <div class="alert <?= strpos($status_msg,'sent')!==false ? 'success':'info'?>"><?=htmlspecialchars($status_msg)?></div>
  <?php endif; ?>

  <table class="admin-table">
    <tr>
      <th>ID</th>
      <th>Client</th>
      <th>Contact</th>
      <th>Metal</th>
      <th>Comments</th>
      <th>File</th>
      <th>Status</th>
      <th>Action</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?=htmlspecialchars($row['id'])?></td>
        <td><?=htmlspecialchars($row['first_name'].' '.$row['last_name'])?><br><span class="small"><?=htmlspecialchars($row['address'])?></span></td>
        <td><?=htmlspecialchars($row['email'])?><br><?=htmlspecialchars($row['phone'])?></td>
        <td><?=htmlspecialchars($row['metal_thickness'])?></td>
        <td><?=nl2br(htmlspecialchars($row['comments']))?></td>
        <td>
          <?php if ($row['filename']): ?>
            <a href="../../private/quotes/<?=urlencode($row['filename'])?>" target="_blank">Download</a>
          <?php else: ?>
            None
          <?php endif; ?>
        </td>
        <td><?=htmlspecialchars($row['status'])?></td>
        <td>
          <?php if ($row['status'] === 'new' || $row['status'] === ''): ?>
            <form method="post" class="quote-action-form">
              <input type="hidden" name="id" value="<?=htmlspecialchars($row['id'])?>">
              <label>Quoted Price
                <input type="text" name="quoted_price" required placeholder="e.g. 1250.00">
              </label>
              <label>Payment Link
                <input type="url" name="payment_link" required placeholder="https://...">
              </label>
              <label>Quote Details
                <textarea name="quote_details" rows="3" required>Metal/Thickness: <?=htmlspecialchars($row['metal_thickness'])?>

Description:
</textarea>
              </label>
              <button type="submit" name="send_quote" class="cta-btn">Send Quote</button>
            </form>
          <?php else: ?>
            <strong>Quote Sent</strong>
            <?php if ($row['payment_link']): ?>
              <div class="small"><a href="<?=htmlspecialchars($row['payment_link'])?>" target="_blank">Payment Link</a></div>
            <?php endif; ?>
          <?php endif; ?>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
</main>
</body>
</html>