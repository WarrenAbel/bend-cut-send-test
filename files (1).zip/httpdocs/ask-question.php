<?php
session_start();
require_once __DIR__ . '/../private/config.php';

// CSRF token
if (!isset($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $error = "Invalid CSRF token.";
  } else {
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $question = trim($_POST['question'] ?? '');

    if ($first_name === '' || $last_name === '' || $email === '' || $question === '') {
      $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $error = "Invalid email address.";
    } else {
      // Store question
      $mysqli = new mysqli($db_host, $db_user, $db_password, $db_name);
      if ($mysqli->connect_errno) {
        $error = "Database error.";
      } else {
        $stmt = $mysqli->prepare("INSERT INTO questions (first_name,last_name,email,question,created_at) VALUES (?,?,?,?,NOW())");
        $stmt->bind_param("ssss", $first_name, $last_name, $email, $question);
        if ($stmt->execute()) {
          $success = "Thank you! Your question has been received.";
          // Auto acknowledgement email
          $subject = "We received your question";
          $msg = "Dear $first_name $last_name,\n\nThank you for your question:\n\n\"$question\"\n\nWe will respond as soon as possible.\n\nBest regards,\n$SITE_NAME Team";
          $headers = "From: $SITE_NAME <".$SITE_EMAIL_FROM.">\r\nContent-Type: text/plain; charset=utf-8\r\n";
          @mail($email, $subject, $msg, $headers);
          $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); // rotate token
        } else {
          $error = "Unable to save your question.";
        }
        $stmt->close();
        $mysqli->close();
      }
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Ask a Question | <?=$SITE_NAME?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/styles.css">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
</head>
<body>
<nav class="navbar">
  <a href="index.php">Home</a>
  <a href="how-it-works.php">How it works</a>
  <a href="metals.php">Metals Available</a>
  <a href="qa.php">Q&amp;A</a>
  <a href="request-quote.php">Request a Quote</a>
  <a href="ask-question.php" class="active">Ask a Question</a>
</nav>
<main class="container">
  <h1>Ask a Question</h1>
  <p>Fill in the form below and we will get back to you.</p>

  <?php if ($error): ?><div class="alert error"><?=htmlspecialchars($error)?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert success"><?=htmlspecialchars($success)?></div><?php endif; ?>

  <form method="post" class="form-card" novalidate>
    <input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['csrf_token'])?>">
    <div class="grid-2">
      <label>First Name
        <input type="text" name="first_name" required value="<?=htmlspecialchars($_POST['first_name'] ?? '')?>">
      </label>
      <label>Last Name
        <input type="text" name="last_name" required value="<?=htmlspecialchars($_POST['last_name'] ?? '')?>">
      </label>
    </div>
    <label>Email
      <input type="email" name="email" required value="<?=htmlspecialchars($_POST['email'] ?? '')?>">
    </label>
    <label>Your Question
      <textarea name="question" rows="6" required><?=htmlspecialchars($_POST['question'] ?? '')?></textarea>
    </label>
    <button type="submit" class="cta-btn">Submit Question</button>
  </form>
</main>
<footer class="site-footer">
  <p>&copy; <?=date('Y')?> <?=$SITE_NAME?>.</p>
</footer>
</body>
</html>