<?php
session_start();
require_once __DIR__ . '/../private/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>How it works | <?=$SITE_NAME?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/styles.css">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
</head>
<body>
<nav class="navbar">
  <a href="index.php">Home</a>
  <a href="how-it-works.php" class="active">How it works</a>
  <a href="metals.php">Metals Available</a>
  <a href="qa.php">Q&amp;A</a>
  <a href="request-quote.php">Request a Quote</a>
  <a href="ask-question.php">Ask a Question</a>
</nav>
<main class="container">
  <h1>How it works</h1>

  <section class="hiw-step">
    <h2>1. Your design – File upload</h2>
    <p>Our machines need to know where to cut, and where and how to bend, if required.</p>
    <p>The best file format is an AutoCAD drawing file (dwg, dwt, dxf, dws, dwf, dwfx, dxb). Most CAD packages can save designs into one of these formats. Show bend positions, angle and bend radius if bends are required.</p>
    <p>If you don’t know CAD, or can’t produce an AutoCAD file, we can work with what you have:</p>
    <ul>
      <li>A picture with measurements</li>
      <li>A sketch with measurements</li>
      <li>A different CAD format</li>
    </ul>
    <p>You also need to specify material type, thickness and surface finish. If unsure, ask—we will advise.</p>
  </section>

  <section class="hiw-step">
    <h2>2. Final design &amp; quote</h2>
    <p>We send a final design for your approval plus a quote, including an estimated delivery date.</p>
    <p>Now is the time to ensure the design meets all requirements. We may propose alternatives that:</p>
    <ul>
      <li>Make the part feasible (some bends that look possible in CAD may not be physically bendable)</li>
      <li>Reduce cost of production or assembly</li>
    </ul>
    <p>Once you approve the final design, you approve the quote (including shipping). The quote depends on:</p>
    <ul>
      <li>Material chosen (type, thickness, finish)</li>
      <li>Material quantity (by weight)</li>
      <li>Total laser cut length (aggregate path of all cuts)</li>
      <li>Number and types of bends</li>
      <li>Required tolerances (see Q&amp;A)</li>
      <li>Assistance needed to finalize the design</li>
      <li>Any specialised metals / finishes / processes</li>
    </ul>
  </section>

  <section class="hiw-step">
    <h2>3. Payment</h2>
    <p>After approval, you receive a secure payment link.</p>
    <p>You can pay using:</p>
    <ul>
      <li>Credit / Debit Card</li>
      <li>Ozow (Instant EFT)</li>
    </ul>
    <p>Once payment is verified we begin manufacturing.</p>
  </section>

  <section class="hiw-step">
    <h2>4. Manufacture and shipping</h2>
    <p>We keep you informed of production progress and send a tracking number when shipped.</p>
  </section>

  <section class="hiw-step">
    <h2>5. Support and returns</h2>
    <p>Reach out any time for help or assembly advice. If the part is damaged in shipping or you are unhappy, contact us.</p>
    <p>If the part matches the approved design and agreed tolerance we generally cannot be responsible for its suitability, but we will try to help modify it (additional cost may apply).</p>
    <p>If we were at fault, we will replace the part at no cost.</p>
  </section>

  <p><a href="request-quote.php" class="cta-btn">Request a Quote</a></p>
</main>
<footer class="site-footer">
  <p>&copy; <?=date('Y')?> <?=$SITE_NAME?>.</p>
</footer>
</body>
</html>