<?php
session_start();
require_once __DIR__ . '/../private/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Home | <?=htmlspecialchars($SITE_NAME)?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="theme-color" content="#016e6f">
  <link rel="icon" href="images/favicon.png" type="image/png">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav class="navbar">
  <a href="index.php" class="active">Home</a>
  <a href="how-it-works.php">How it works</a>
  <a href="metals.php">Metals Available</a>
  <a href="qa.php">Q&amp;A</a>
  <a href="request-quote.php">Request a Quote</a>
  <a href="ask-question.php">Ask a Question</a>
</nav>

<header class="hero-bg">
  <img src="images/hero_bend_cut_send.jpg" alt="Bend Cut Send" class="hero-image">
  <div class="hero-overlay">
    <h1 class="hero-title">Bend. Cut. Send.</h1>
    <p class="hero-subtitle">Precision sheet metal parts made to your design.</p>
    <a href="request-quote.php" class="cta-btn">Get a Quote</a>
  </div>
</header>

<main class="container">
  <section>
    <h2>Welcome to <?=htmlspecialchars($SITE_NAME)?></h2>
    <p>We laser cut and bend your custom metal parts based on your design. Upload your drawing, approve the final design, pay securely (Debit/Credit Card or Ozow Instant EFT), and we manufacture and ship.</p>
  </section>

  <section class="steps-grid">
    <article>
      <h3>1. Upload Design</h3>
      <p>Provide an AutoCAD file (dwg/dxf/etc.) or even a sketch with measurements.</p>
    </article>
    <article>
      <h3>2. Approve Quote</h3>
      <p>We refine the design if needed and send you a quote with delivery estimate.</p>
    </article>
    <article>
      <h3>3. Secure Payment</h3>
      <p>Pay via Debit/Credit Card or Ozow Instant EFT on our secure payment portal.</p>
    </article>
    <article>
      <h3>4. Manufacture</h3>
      <p>Your part is laser cut, bent and prepared to spec. We keep you informed.</p>
    </article>
    <article>
      <h3>5. Shipping & Support</h3>
      <p>Track delivery and get ongoing support. If we made a mistake, we make it right.</p>
    </article>
  </section>

  <section>
    <h2>Ready to begin?</h2>
    <p>Request a quote now with your design and material requirements.</p>
    <a href="request-quote.php" class="cta-btn accent">Request a Quote</a>
  </section>
</main>

<footer class="site-footer">
  <p>&copy; <?=date('Y')?> <?=htmlspecialchars($SITE_NAME)?>. All rights reserved.</p>
</footer>
</body>
</html>