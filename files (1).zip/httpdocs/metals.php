<?php
session_start();
require_once __DIR__ . '/../private/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Metals Available | <?=$SITE_NAME?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/styles.css">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
</head>
<body>
<nav class="navbar">
  <a href="index.php">Home</a>
  <a href="how-it-works.php">How it works</a>
  <a href="metals.php" class="active">Metals Available</a>
  <a href="qa.php">Q&amp;A</a>
  <a href="request-quote.php">Request a Quote</a>
  <a href="ask-question.php">Ask a Question</a>
</nav>
<main class="container">
  <h1>Metals Available</h1>

  <h2>Mild Steel</h2>
  <table class="data-table">
    <thead><tr><th>Finish</th><th>Thickness (mm)</th></tr></thead>
    <tbody>
      <tr><td>Cold Rolled</td><td>0.8, 1.0, 1.2</td></tr>
      <tr><td>Hot Rolled</td><td>1.6, 2.0, 2.5, 3.0, 4.0, 4.5, 5.0, 6.0, 8.0, 10.0</td></tr>
      <tr><td>Galvanised</td><td>0.6, 0.8, 1.0, 1.2, 1.5, 2.0, 2.5, 3.0</td></tr>
    </tbody>
  </table>

  <h2>3CR12 Stainless Steel</h2>
  <table class="data-table">
    <thead><tr><th>Finish</th><th>Thickness (mm)</th></tr></thead>
    <tbody>
      <tr><td>2D</td><td>1.0, 1.2, 1.5, 2.0, 2.5</td></tr>
      <tr><td>No.1</td><td>3.0, 4.5, 6.0, 8.0, 10.0</td></tr>
    </tbody>
  </table>

  <h2>430 Stainless Steel</h2>
  <table class="data-table">
    <thead><tr><th>Finish</th><th>Thickness (mm)</th></tr></thead>
    <tbody>
      <tr><td>BA</td><td>0.7, 0.9, 1.2, 1.5</td></tr>
      <tr><td>2B</td><td>2.0</td></tr>
      <tr><td>PVC BA</td><td>0.7, 0.9, 1.2, 1.5</td></tr>
      <tr><td>2B PVC</td><td>2.0</td></tr>
      <tr><td>No.4 PVC</td><td>0.7, 0.9, 1.2 (x2), 1.5, 2.0</td></tr>
    </tbody>
  </table>

  <h2>304 Stainless Steel</h2>
  <table class="data-table">
    <thead><tr><th>Finish</th><th>Thickness (mm)</th></tr></thead>
    <tbody>
      <tr><td>2B</td><td>0.7, 0.9, 1.2, 1.5, 2.0, 2.5, 3.0, 4.0</td></tr>
      <tr><td>No.1</td><td>4.5, 6.0, 8.0, 10.0</td></tr>
      <tr><td>2B PVC</td><td>0.7, 0.9, 1.2, 1.5, 2.0, 2.5, 3.0, 4.0</td></tr>
      <tr><td>No.4 PVC</td><td>0.7, 0.9, 1.2, 1.5, 2.0, 2.5, 3.0, 4.0</td></tr>
    </tbody>
  </table>

  <h2>316 Stainless Steel</h2>
  <table class="data-table">
    <thead><tr><th>Finish</th><th>Thickness (mm)</th></tr></thead>
    <tbody>
      <tr><td>2B</td><td>0.7, 0.9, 1.2, 1.5, 2.0, 2.5, 3.0, 4.0</td></tr>
      <tr><td>No.1</td><td>4.5, 6.0, 8.0, 10.0</td></tr>
      <tr><td>2B PVC</td><td>0.7, 0.9, 1.2, 1.5, 2.0, 2.5, 3.0, 4.0</td></tr>
      <tr><td>No.4 PVC</td><td>0.7, 0.9, 1.2, 1.5, 2.0, 2.5, 3.0, 4.0</td></tr>
    </tbody>
  </table>

  <h2>Aluminium 1050</h2>
  <table class="data-table">
    <thead><tr><th>Finish</th><th>Thickness (mm)</th></tr></thead>
    <tbody>
      <tr><td>Mill</td><td>1.2, 1.5, 2.0, 3.0, 4.5, 6.0</td></tr>
      <tr><td>Mill PVC</td><td>1.2, 1.5, 2.0, 3.0</td></tr>
    </tbody>
  </table>

  <p><a href="request-quote.php" class="cta-btn">Request a Quote</a></p>
</main>
<footer class="site-footer">
  <p>&copy; <?=date('Y')?> <?=$SITE_NAME?>.</p>
</footer>
</body>
</html>