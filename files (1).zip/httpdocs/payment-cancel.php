<?php ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Payment Cancelled</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav class="navbar">
  <a href="index.php">Home</a>
  <a href="request-quote.php">Request a Quote</a>
</nav>
<main class="container">
  <h1>Payment Cancelled</h1>
  <p>Your payment was cancelled. If this was a mistake, you can try again.</p>
  <p><a href="payment.php" class="cta-btn">Retry Payment</a></p>
</main>
</body>
</html>