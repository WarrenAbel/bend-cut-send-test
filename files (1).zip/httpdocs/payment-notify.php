<?php
// PayFast ITN (Instant Transaction Notification) handler
// Validate posted data according to PayFast docs (signature, source IP, etc.)
// This file should not output anything visible to user except a 200 OK after processing.

require_once __DIR__ . '/../private/config.php';

// Collect POST
$data = $_POST;

// TODO: Implement signature verification & security checks per PayFast documentation.
// Update relevant order/quote in database after verifying.

http_response_code(200);
exit;