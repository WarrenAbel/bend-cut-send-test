<?php
// Handle successful return from PayFast (verify via ITN notify endpoint for certainty)
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Payment Successful | Thank You</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav class="navbar">
  <a href="index.php">Home</a>
  <a href="request-quote.php">Request a Quote</a>
</nav>
<main class="container">
  <h1>Payment Successful</h1>
  <p>Thank you. We have received your payment. Production will begin shortly and you will receive updates.</p>
  <p><a href="index.php" class="cta-btn">Return Home</a></p>
</main>
</body>
</html>