<?php
// Example PayFast form (could also integrate Peach Payments or others)
// Adjust credentials and pass amount after quoting process.
session_start();
require_once __DIR__ . '/../private/config.php';

// Demo values - in production fetch from DB for a specific order.
$merchant_id = "10000100"; // Replace with real
$merchant_key = "46f0cd694581a"; // Replace with real
$return_url = $PAYFAST_RETURN_URL;
$cancel_url = $PAYFAST_CANCEL_URL;
$notify_url = $PAYFAST_NOTIFY_URL;
$amount = "500.00"; // Example amount
$item_name = "Custom Metal Part";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Payment | <?=$SITE_NAME?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<nav class="navbar">
  <a href="index.php">Home</a>
  <a href="how-it-works.php">How it works</a>
  <a href="metals.php">Metals Available</a>
  <a href="qa.php">Q&amp;A</a>
  <a href="request-quote.php">Request a Quote</a>
  <a href="ask-question.php">Ask a Question</a>
</nav>
<main class="container">
  <h1>Secure Payment</h1>
  <p>Pay via Debit/Credit Card or Ozow (Instant EFT) using PayFast’s secure portal.</p>

  <form action="https://www.payfast.co.za/eng/process" method="post" class="form-card">
    <input type="hidden" name="merchant_id" value="<?=htmlspecialchars($merchant_id)?>">
    <input type="hidden" name="merchant_key" value="<?=htmlspecialchars($merchant_key)?>">
    <input type="hidden" name="return_url" value="<?=htmlspecialchars($return_url)?>">
    <input type="hidden" name="cancel_url" value="<?=htmlspecialchars($cancel_url)?>">
    <input type="hidden" name="notify_url" value="<?=htmlspecialchars($notify_url)?>">
    <input type="hidden" name="amount" value="<?=htmlspecialchars($amount)?>">
    <input type="hidden" name="item_name" value="<?=htmlspecialchars($item_name)?>">
    <button type="submit" class="cta-btn accent">Proceed to PayFast</button>
  </form>
</main>
<footer class="site-footer">
  <p>&copy; <?=date('Y')?> <?=$SITE_NAME?>.</p>
</footer>
</body>
</html>