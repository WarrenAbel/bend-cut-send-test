<?php
session_start();
require_once __DIR__ . '/../private/config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Q&amp;A | <?=$SITE_NAME?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/styles.css">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
</head>
<body>
<nav class="navbar">
  <a href="index.php">Home</a>
  <a href="how-it-works.php">How it works</a>
  <a href="metals.php">Metals Available</a>
  <a href="qa.php" class="active">Q&amp;A</a>
  <a href="request-quote.php">Request a Quote</a>
  <a href="ask-question.php">Ask a Question</a>
</nav>
<main class="container">
  <h1>Q &amp; A</h1>

  <table class="qa-table">
    <thead>
      <tr><th style="width:30%">Question</th><th>Answer</th></tr>
    </thead>
    <tbody>
      <tr>
        <td>What are your tolerances?</td>
        <td>
          <p>Cutting: normally within 0.25mm. Bending: typically +/- 1mm (critical bending tolerance must be communicated).</p>
          <h4>Key Bending Parameters</h4>
          <ul>
            <li><strong>Minimum Bend Radius:</strong> Soft materials (Aluminium, Mild Steel): ~1× thickness. Harder materials: often ≥2× thickness.</li>
            <li><strong>General Rule:</strong> 2–6 mm thick: radius ~1× thickness; thicker parts: 2–3× recommended.</li>
            <li><strong>Minimum Flange Length:</strong> Often 4× thickness or 12 mm, whichever greater.</li>
            <li><strong>Z-Bends:</strong> Maintain minimum X distance to avoid tool collisions.</li>
            <li><strong>Feature Spacing:</strong> Keep holes/bends ≥4× thickness from bend lines.</li>
            <li><strong>Curls:</strong> Spacing ≥ curl radius + sheet thickness.</li>
          </ul>
          <h4>Tolerances</h4>
          <ul>
            <li><strong>Bend Angle:</strong> ±1° typical</li>
            <li><strong>Bend Length:</strong> ±0.20 mm per bend</li>
            <li><strong>ISO 2768:</strong> Referenced for general linear/angular/geometric tolerances.</li>
          </ul>
        </td>
      </tr>
      <tr>
        <td>Do you have tips for effective bending?</td>
        <td>
          <ul>
            <li>Avoid acute angles &lt; 130°.</li>
            <li>Avoid very obtuse angles &gt; 175° (original list note likely intended "greater than 175°").</li>
            <li>Space successive bends as far apart as possible.</li>
            <li>Consider material hardness and yield strength for bend feasibility.</li>
          </ul>
        </td>
      </tr>
      <tr>
        <td>What metals do you offer?</td>
        <td>
          <p>If you need something not listed, please reach out.</p>
          <ul>
            <li><strong>Mild Steel:</strong> Low-carbon, ductile, malleable, widely used.</li>
            <li><strong>3CR12 Stainless Steel:</strong> Utility ferritic stainless; corrosion resistant and cost-effective bridge between mild steel and austenitic grades.</li>
            <li><strong>430 Stainless Steel:</strong> Ferritic, chromium only; good corrosion resistance, affordable.</li>
            <li><strong>304 Stainless Steel:</strong> Austenitic “workhorse”; excellent corrosion resistance, formability.</li>
            <li><strong>316 Stainless Steel:</strong> Marine-grade; superior chloride corrosion resistance.</li>
            <li><strong>Aluminium 1050:</strong> Commercially pure; excellent corrosion resistance, high ductility, thermal &amp; electrical conductivity.</li>
          </ul>
        </td>
      </tr>
      <tr>
        <td>How do I design a part?</td>
        <td>
          <p>Refer to the <a href="how-it-works.php">How it works</a> section.</p>
          <ul>
            <li>Start with required shape and dimensions (measure carefully).</li>
            <li>If you lack CAD skills, send a picture/drawing with critical dimensions and material thickness.</li>
            <li>We can advise if you need help refining the design.</li>
            <li>Learning CAD lets you iterate; choose tools with strong communities.</li>
          </ul>
        </td>
      </tr>
      <tr>
        <td>How do returns work?</td>
        <td>
          <p>See <a href="how-it-works.php">How it works</a> for detail.</p>
          <p>Custom parts made to approved design and tolerance generally aren’t returnable for suitability reasons.</p>
          <p>If we made an error, we replace at no additional cost.</p>
        </td>
      </tr>
      <tr>
        <td>What are the different surface finishes?</td>
        <td>
          <p>Refer to the <a href="metals.php">Materials available</a> page for finish availability per metal.</p>
          <ul>
            <li><strong>Hot Rolled:</strong> Rough, scale, less precise dimensions, cheaper.</li>
            <li><strong>Cold Rolled:</strong> Smooth, precise dimension control, higher strength, higher cost.</li>
            <li><strong>Galvanised:</strong> Zinc coating for corrosion resistance; durable, cost-effective.</li>
            <li><strong>2D:</strong> Dull, matte, non-reflective, pickled for corrosion resistance.</li>
            <li><strong>No.1:</strong> Rough, dull, cost-effective for industrial use.</li>
            <li><strong>BA:</strong> Bright annealed, mirror-like, hygienic, enhanced corrosion protection.</li>
            <li><strong>2B:</strong> Smooth, semi-reflective, economical.</li>
            <li><strong>2B PVC / BA PVC / No.4 PVC:</strong> Protective film to prevent scratches during handling.</li>
            <li><strong>No.4 PVC:</strong> Satin/brushed, repairable with light abrasive pads.</li>
          </ul>
        </td>
      </tr>
    </tbody>
  </table>

  <p><a href="ask-question.php" class="cta-btn">Ask a Question</a> <a href="request-quote.php" class="cta-btn accent">Request a Quote</a></p>
</main>
<footer class="site-footer">
  <p>&copy; <?=date('Y')?> <?=$SITE_NAME?>.</p>
</footer>
</body>
</html>