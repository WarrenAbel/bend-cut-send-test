<?php
session_start();
require_once __DIR__ . '/../private/config.php';

if (!isset($_SESSION['csrf_token'])) {
  $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$success = '';
$error = '';

$metal_options = [
  "Mild Steel - cold rolled - 0.8mm",
  "Mild Steel - cold rolled - 1.0mm",
  "Mild Steel - cold rolled - 1.2mm",
  "Mild Steel - hot rolled - 1.6mm",
  "Mild Steel - hot rolled - 2.0mm",
  "Mild Steel - hot rolled - 2.5mm",
  "Mild Steel - hot rolled - 3.0mm",
  "Mild Steel - hot rolled - 4.0mm",
  "Mild Steel - hot rolled - 4.5mm",
  "Mild Steel - hot rolled - 5.0mm",
  "Mild Steel - hot rolled - 6.0mm",
  "Mild Steel - hot rolled - 8.0mm",
  "Mild Steel - hot rolled - 10.0mm",
  "Mild Steel - Galvanised - 0.6mm",
  "Mild Steel - Galvanised - 0.8mm",
  "Mild Steel - Galvanised - 1.0mm",
  "Mild Steel - Galvanised - 1.2mm",
  "Mild Steel - Galvanised - 1.5mm",
  "Mild Steel - Galvanised - 2.0mm",
  "Mild Steel - Galvanised - 2.5mm",
  "Mild Steel - Galvanised - 3.0mm",
  "3CR12 Stainless Steel - 2D - 1.0mm",
  "3CR12 Stainless Steel - 2D - 1.5mm",
  "3CR12 Stainless Steel - 2D - 2.0mm",
  "3CR12 Stainless Steel - 2D - 2.5mm",
  "3CR12 Stainless Steel - No.1 - 3.0mm",
  "3CR12 Stainless Steel - No.1 - 4.5mm",
  "3CR12 Stainless Steel - No.1 - 6.0mm",
  "3CR12 Stainless Steel - No.1 - 8.0mm",
  "3CR12 Stainless Steel - No.1 - 10.0mm",
  "430 Stainless Steel - BA - 0.7mm",
  "430 Stainless Steel - BA - 0.9mm",
  "430 Stainless Steel - BA - 1.2mm",
  "430 Stainless Steel - BA - 1.5mm",
  "430 Stainless Steel - 2B - 2.0mm",
  "430 Stainless Steel - PVC BA - 0.7mm",
  "430 Stainless Steel - PVC BA - 0.9mm",
  "430 Stainless Steel - PVC BA - 1.2mm",
  "430 Stainless Steel - PVC BA - 1.5mm",
  "430 Stainless Steel - 2B PVC - 2.0mm",
  "430 Stainless Steel - No.4 PVC - 0.7mm",
  "430 Stainless Steel - No.4 PVC - 0.9mm",
  "430 Stainless Steel - No.4 PVC - 1.2mm",
  "430 Stainless Steel - No.4 PVC - 1.5mm",
  "430 Stainless Steel - No.4 PVC - 2.0mm",
  "304 Stainless Steel - 2B - 0.7mm",
  "304 Stainless Steel - 2B - 0.9mm",
  "304 Stainless Steel - 2B - 1.2mm",
  "304 Stainless Steel - 2B - 1.5mm",
  "304 Stainless Steel - 2B - 2.0mm",
  "304 Stainless Steel - 2B - 2.5mm",
  "304 Stainless Steel - 2B - 3.0mm",
  "304 Stainless Steel - 2B - 4.0mm",
  "304 Stainless Steel - No.1 - 4.5mm",
  "304 Stainless Steel - No.1 - 6.0mm",
  "304 Stainless Steel - No.1 - 8.0mm",
  "304 Stainless Steel - No.1 - 10.0mm",
  "304 Stainless Steel - 2B PVC - 0.7mm",
  "304 Stainless Steel - 2B PVC - 0.9mm",
  "304 Stainless Steel - 2B PVC - 1.2mm",
  "304 Stainless Steel - 2B PVC - 1.5mm",
  "304 Stainless Steel - 2B PVC - 2.0mm",
  "304 Stainless Steel - 2B PVC - 2.5mm",
  "304 Stainless Steel - 2B PVC - 3.0mm",
  "304 Stainless Steel - 2B PVC - 4.0mm",
  "304 Stainless Steel - No.4 PVC - 0.7mm",
  "304 Stainless Steel - No.4 PVC - 0.9mm",
  "304 Stainless Steel - No.4 PVC - 1.2mm",
  "304 Stainless Steel - No.4 PVC - 1.5mm",
  "304 Stainless Steel - No.4 PVC - 2.0mm",
  "304 Stainless Steel - No.4 PVC - 2.5mm",
  "304 Stainless Steel - No.4 PVC - 3.0mm",
  "304 Stainless Steel - No.4 PVC - 4.0mm",
  "316 Stainless Steel - 2B - 0.7mm",
  "316 Stainless Steel - 2B - 0.9mm",
  "316 Stainless Steel - 2B - 1.2mm",
  "316 Stainless Steel - 2B - 1.5mm",
  "316 Stainless Steel - 2B - 2.0mm",
  "316 Stainless Steel - 2B - 2.5mm",
  "316 Stainless Steel - 2B - 3.0mm",
  "316 Stainless Steel - 2B - 4.0mm",
  "316 Stainless Steel - No.1 - 4.5mm",
  "316 Stainless Steel - No.1 - 6.0mm",
  "316 Stainless Steel - No.1 - 8.0mm",
  "316 Stainless Steel - No.1 - 10.0mm",
  "316 Stainless Steel - 2B PVC - 0.7mm",
  "316 Stainless Steel - 2B PVC - 0.9mm",
  "316 Stainless Steel - 2B PVC - 1.2mm",
  "316 Stainless Steel - 2B PVC - 1.5mm",
  "316 Stainless Steel - 2B PVC - 2.0mm",
  "316 Stainless Steel - 2B PVC - 2.5mm",
  "316 Stainless Steel - 2B PVC - 3.0mm",
  "316 Stainless Steel - 2B PVC - 4.0mm",
  "316 Stainless Steel - No.4 PVC - 0.7mm",
  "316 Stainless Steel - No.4 PVC - 0.9mm",
  "316 Stainless Steel - No.4 PVC - 1.2mm",
  "316 Stainless Steel - No.4 PVC - 1.5mm",
  "316 Stainless Steel - No.4 PVC - 2.0mm",
  "316 Stainless Steel - No.4 PVC - 2.5mm",
  "316 Stainless Steel - No.4 PVC - 3.0mm",
  "316 Stainless Steel - No.4 PVC - 4.0mm",
  "Aluminium 1050 - Mill - 1.2mm",
  "Aluminium 1050 - Mill - 1.5mm",
  "Aluminium 1050 - Mill - 2.0mm",
  "Aluminium 1050 - Mill - 3.0mm",
  "Aluminium 1050 - Mill - 4.5mm",
  "Aluminium 1050 - Mill - 6.0mm",
  "Aluminium 1050 - Mill PVC - 1.2mm",
  "Aluminium 1050 - Mill PVC - 1.5mm",
  "Aluminium 1050 - Mill PVC - 2.0mm",
  "Aluminium 1050 - Mill PVC - 3.0mm"
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $error = "Invalid CSRF token.";
  } else {
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $metal_thickness = trim($_POST['metal_thickness'] ?? '');
    $comments = trim($_POST['comments'] ?? '');

    if ($first_name === '' || $last_name === '' || $email === '' || $phone === '' || $address === '' || $metal_thickness === '') {
      $error = "Please fill in all required fields.";
    } elseif (!in_array($metal_thickness, $metal_options)) {
      $error = "Invalid metal selection.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $error = "Invalid email address.";
    } else {
      $filename_stored = '';
      if (!empty($_FILES['design_file']['name'])) {
        $allowed_ext = ['dwg','dwt','dxf','dws','dwf','dwfx','dxb','pdf','stl','jpeg','jpg','png','tiff','bmp'];
        $orig_name = $_FILES['design_file']['name'];
        $tmp = $_FILES['design_file']['tmp_name'];
        $size = $_FILES['design_file']['size'];
        $ext = strtolower(pathinfo($orig_name, PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed_ext)) {
          $error = "File type not allowed.";
        } elseif ($size > 25 * 1024 * 1024) { // 25MB limit
          $error = "File too large (max 25MB).";
        } else {
          $filename_stored = time() . '_' . preg_replace('/[^A-Za-z0-9_\.-]/','_', $orig_name);
          $dest_dir = __DIR__ . '/../private/quotes/';
          if (!is_dir($dest_dir)) {
            @mkdir($dest_dir, 0700, true);
          }
          if (!move_uploaded_file($tmp, $dest_dir . $filename_stored)) {
            $error = "Failed to store uploaded file.";
          }
        }
      }

      if (!$error) {
        $mysqli = new mysqli($db_host, $db_user, $db_password, $db_name);
        if ($mysqli->connect_errno) {
          $error = "Database connection failed.";
        } else {
          $stmt = $mysqli->prepare("INSERT INTO quote_requests (first_name,last_name,email,phone,address,metal_thickness,comments,filename,status,created_at) VALUES (?,?,?,?,?,?,?,?, 'new', NOW())");
          $stmt->bind_param("ssssssss", $first_name,$last_name,$email,$phone,$address,$metal_thickness,$comments,$filename_stored);
          if ($stmt->execute()) {
            $success = "Your quote request has been submitted successfully!";
            // Send thank you email
            $client_subject = "Thank you for your quote request";
            $client_message = "Dear $first_name $last_name,

Thank you for submitting your quote request to $SITE_NAME.
We have received your details and are working on a quotation for you.

We'll be in touch soon!

Best regards,
$SITE_NAME Team
";
            $client_headers  = "From: $SITE_NAME <".$SITE_EMAIL_FROM.">\r\n";
            $client_headers .= "Reply-To: ".$SITE_EMAIL_FROM."\r\n";
            $client_headers .= "Content-Type: text/plain; charset=utf-8\r\n";
            @mail($email, $client_subject, $client_message, $client_headers);
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            // Clear POST values
            $_POST = [];
          } else {
            $error = "Could not save your request.";
          }
          $stmt->close();
          $mysqli->close();
        }
      }
    }
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Request a Quote | <?=$SITE_NAME?></title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="css/styles.css">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
</head>
<body>
<nav class="navbar">
  <a href="index.php">Home</a>
  <a href="how-it-works.php">How it works</a>
  <a href="metals.php">Metals Available</a>
  <a href="qa.php">Q&amp;A</a>
  <a href="request-quote.php" class="active">Request a Quote</a>
  <a href="ask-question.php">Ask a Question</a>
</nav>
<main class="container">
  <h1>Request a Quote</h1>
  <p>Provide your details, material selection, and optional design file.</p>

  <?php if ($error): ?><div class="alert error"><?=htmlspecialchars($error)?></div><?php endif; ?>
  <?php if ($success): ?><div class="alert success"><?=htmlspecialchars($success)?></div><?php endif; ?>

  <form method="post" enctype="multipart/form-data" class="form-card" novalidate>
    <input type="hidden" name="csrf_token" value="<?=htmlspecialchars($_SESSION['csrf_token'])?>">
    <div class="grid-2">
      <label>First Name
        <input type="text" name="first_name" required value="<?=htmlspecialchars($_POST['first_name'] ?? '')?>">
      </label>
      <label>Last Name
        <input type="text" name="last_name" required value="<?=htmlspecialchars($_POST['last_name'] ?? '')?>">
      </label>
    </div>
    <label>Email
      <input type="email" name="email" required value="<?=htmlspecialchars($_POST['email'] ?? '')?>">
    </label>
    <label>Phone Number
      <input type="text" name="phone" required value="<?=htmlspecialchars($_POST['phone'] ?? '')?>">
    </label>
    <label>Full Address
      <textarea name="address" rows="3" required><?=htmlspecialchars($_POST['address'] ?? '')?></textarea>
    </label>
    <label>Metal &amp; Thickness
      <select name="metal_thickness" required>
        <option value="">-- Select --</option>
        <?php foreach ($metal_options as $opt): ?>
          <option value="<?=htmlspecialchars($opt)?>" <?= (($_POST['metal_thickness'] ?? '') === $opt ? 'selected':'')?>><?=htmlspecialchars($opt)?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Comments
      <textarea name="comments" rows="5"><?=htmlspecialchars($_POST['comments'] ?? '')?></textarea>
    </label>
    <label>Design File (optional)
      <input type="file" name="design_file" accept=".dwg,.dwt,.dxf,.dws,.dwf,.dwfx,.dxb,.pdf,.stl,.jpeg,.jpg,.png,.tiff,.bmp">
      <small>Allowed: dwg, dwt, dxf, dws, dwf, dwfx, dxb, pdf, stl, jpeg, jpg, png, tiff, bmp (Max 25MB)</small>
    </label>
    <button type="submit" class="cta-btn">Submit Request</button>
  </form>
</main>
<footer class="site-footer">
  <p>&copy; <?=date('Y')?> <?=$SITE_NAME?>.</p>
</footer>
</body>
</html>