<?php
// Configuration file (never expose publicly)
// Move outside /httpdocs if possible; here assumed under /private/ with .htaccess protection.

// ---- Site Settings ----
$SITE_NAME = "Your Company Name";
$SITE_EMAIL_FROM = "yourcompany@example.com";

// ---- Database Credentials (replace placeholders) ----
$db_host = "localhost";
$db_user = "dbuser";
$db_password = "dbpassword";
$db_name = "dbname";

// ---- Admin Credentials ----
// Store password as SHA256 hash of the plain password.
$ADMIN_USER = "admin";
$ADMIN_PASS_HASH = hash('sha256', 'ChangeThisAdminPassword!'); // Change and re-generate

// ---- PayFast Integration Settings (replace with real merchant details) ----
$PAYFAST_RETURN_URL = "https://yourdomain.example.com/payment-return.php";
$PAYFAST_CANCEL_URL = "https://yourdomain.example.com/payment-cancel.php";
$PAYFAST_NOTIFY_URL = "https://yourdomain.example.com/payment-notify.php";

// ---- Error Reporting (development) ----
// ini_set('display_errors', 1);
// error_reporting(E_ALL);